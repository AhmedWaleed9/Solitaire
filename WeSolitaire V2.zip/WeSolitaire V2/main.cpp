#include <SFML/Graphics.hpp>
#include "Card.h"
#include "Deck.h"
#include "Display.h"
#include"CardGenerator.h"
#include <unistd.h>
using namespace sf;

int main()
{
    //All Piles [In game class]
    Column columns_array[7];
    Deck deck;
	CardGenerator card_generator;
    card_generator.generateCards(columns_array,deck);
    FoundationPiles hearts("Hearts");
    FoundationPiles spades("Spades");
    FoundationPiles clubs("Clubs");
    FoundationPiles diamonds("Diamonds");
    //////////////////////////////////////////
    Display game(1920 , 1080);
    game.Loop(deck,spades,hearts,diamonds,clubs,columns_array);
    return 0;
};
