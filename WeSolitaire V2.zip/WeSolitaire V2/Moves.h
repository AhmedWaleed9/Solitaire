//
// Created by Ahmed Waleed on 12/30/2022.
//
#pragma once
#include <bits/stdc++.h>
#include "Card.h"

class Moves {
	int ctr;
	int limit;
	stack<pair<string, Card *>> moves;
public:
	Moves();

	// Setters
	void setLimit(int l);

	// Methods
	void addMove(pair<string, Card *> p);

	pair<string, Card *> undoMove();
};


