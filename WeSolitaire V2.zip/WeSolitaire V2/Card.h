//
// Created by Yassin on 12/23/2022.
//
#include<bits/stdc++.h>
#include<SFML/Graphics.hpp>

using namespace std;
using namespace sf;
#pragma once


class Card
{
private:
	string suit;
	string number;
	bool color;   // black = 0, red = 1
	bool flipped; // flipped means that you can see it.
	//pointers that point to the above and below cards
	Card* above;
	Card* below;

	Texture texture;

public:
	Sprite sprite;

	// Constructor
	Card();

	Card(string const&, string const&);

	//Setters
	void setAbove(Card*);

	void setBelow(Card*);

	void setPosition(float , float );

	void setPosition(sf::Vector2<float>&);

	void setTexture();

	// Getters
	string getName();

	bool getColor();

	int getNumber();

	string getSuit();

	Card* getAbove();

	Card* getBelow();



	//Methods
	void flipCard();//switches the flags

	bool isFlipped();//if it faces you then it is flipped

};

