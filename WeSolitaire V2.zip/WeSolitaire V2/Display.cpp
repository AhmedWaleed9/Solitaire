// Created by mahmoud & yassin on 12/25/2022.
//
#include "Display.h"

//Constructors
Display::Display() = default;

Display::Display(int width, int height)
{
	window.create(VideoMode(width, height), "We Solitaire");
	window.setFramerateLimit(60);
}

//Display the deck
void Display::displayDeck(Deck deck)
{
	Texture texture;
	Sprite sprite;
	if (deck.isDeckEmpty())
	{
		texture.loadFromFile("C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\cards\\no_card.bmp");
		sprite.setTexture(texture);
		sprite.setPosition(deck_position);
		window.draw(sprite);
	}
	else
	{
		texture.loadFromFile("C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\cards/card_back.bmp");
		sprite.setTexture(texture);
		sprite.setPosition(deck_position);
		window.draw(sprite);
	}
}

///Display the draws
void Display::displayDraws(Deck& deck)
{
	Texture texture;
	Sprite sprite;
	if (deck.isDrawsEmpty())
	{
		texture.loadFromFile("C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\cards/no_card.bmp");
		sprite.setTexture(texture);
		sprite.setPosition(draws_position);
		window.draw(sprite);
	}
	else
	{
//		card_sprite_map[deck.top().getName()].first.setPosition(draws_position);
//		card_sprite_map[deck.top().getName()].first.setTexture(card_sprite_map[deck.top().getName()].second);
//		window.draw(card_sprite_map[deck.top().getName()].first);
		deck.top()->setTexture();
		deck.top()->setPosition(draws_position);
		window.draw(deck.top()->sprite);
	}
}

void Display::displayFoundationPiles(FoundationPiles& foundationPiles)
{
	Texture texture;
	Sprite sprite;
	if (foundationPiles.isEmpty())
	{
		texture.loadFromFile(
				"C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\cards/" + foundationPiles.getName());
		sprite.setTexture(texture);
		sprite.setPosition(found_distance, 20);
		window.draw(sprite);
	}
	else
	{
		foundationPiles.getTop()->setTexture();
		foundationPiles.getTop()->setPosition(found_distance, 20);
		window.draw(foundationPiles.getTop()->sprite);
	}
	found_distance += 160;
	if (found_distance >= 1840)
	{ found_distance = 1200; }
}

void Display::displayColumn(Column* column_array)
{
	float dx = 35, dy = 350;
	Texture texture;
	Sprite sprite;
	for (int i = 0; i < 7; i++)
	{
		Card* iterator = column_array[i].getHead();
		if (iterator == NULL)
		{
			texture.loadFromFile("C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\cards/no_card.bmp");
			sprite.setTexture(texture);
			sprite.setPosition(dx, dy);
			window.draw(sprite);
		}
		else
		{
			while (iterator != NULL)
			{
				if (iterator->isFlipped())
				{
					iterator->setTexture();
					iterator->setPosition(dx, dy);
					window.draw(iterator->sprite);
				}
				else
				{
					texture.loadFromFile(
							"C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\cards/card_back.bmp");
					sprite.setTexture(texture);
					sprite.setPosition(dx, dy);
					window.draw(sprite);
				}
				dy += 40;
				iterator = iterator->getBelow();
			}
		}
		dy = 350;
		dx += 200;
	}
}

void Display::windowDisplay()
{
	window.display();
}

void Display::Loop(Deck& deck, FoundationPiles& Spades, FoundationPiles& Hearts, FoundationPiles& Diamonds,
		FoundationPiles& Clubs, Column* column_array)
{
	Texture texture;
	Sprite background;
	texture.loadFromFile("C:\\Users\\Yassin\\Desktop\\WeSolitaire V2\\Resources\\Images\\backgrounds/background.jpeg");
	background.setTexture(texture);
	background.setScale(1920 / background.getLocalBounds().width, 1080 / background.getLocalBounds().height);
	while (window.isOpen())
	{
		Event event;
		Mouse mouse;
		while (window.pollEvent(event))
		{
			//This is temp tester
			if (event.type == Event::Closed)
			{
				window.close();
			}
			else if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left)
			{
				//if mouse withinrange of deck
				deck.draw();
			}
			else if (Keyboard::isKeyPressed(sf::Keyboard::Space))
			{
				Spades.put(*deck.top());
				deck.pick();
			}
			else if (event.type == Event::KeyPressed)
			{ deck.pick(); }
			//Tester ends here
		}
		window.clear();
		window.draw(background);
		displayDeck(deck);
		displayDraws(deck);
		displayColumn(column_array);
		displayFoundationPiles(Spades);
		displayFoundationPiles(Hearts);
		displayFoundationPiles(Diamonds);
		displayFoundationPiles(Clubs);
		windowDisplay();
	}
}








//void Display::clear()
//{
//	window.clear();
//}

//bool Display::isWindowOpen()
//{
//	return window.isOpen();
//}

//bool Display::pollEvent(Event event)
//{
//	return window.pollEvent(event);
//}

