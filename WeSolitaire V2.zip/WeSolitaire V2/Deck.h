#pragma once

#include <iostream>
#include <SFML/Graphics.hpp>
#include "Card.h"
#include <stack>

using namespace std;
using namespace sf;

class Deck
{
	stack<Card> deck;
	stack<Card> draws;
public:
	//Constructor
	Deck();

	//Methods
	void refill();

//    void shuffle();
	bool isDeckEmpty();

	bool isDrawsEmpty();

	void draw();

	Card* top();

	void pick();//Picks a card from the deck
	void place(Card c);

	void add(Card c);
};