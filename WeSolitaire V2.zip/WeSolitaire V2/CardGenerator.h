//
// Created by Yassin on 12/25/2022.
//

#pragma once

#include"SFML/Graphics.hpp"
#include"Column.h"
#include"Deck.h"


class CardGenerator
{
private:
	vector<Card> cards_vector;
	int index;
public:
	//Constructor
	CardGenerator();

	//Methods
	void createCards();

	void shuffleCards();

	void generateCards(Column* columns_arr, Deck&);


};



